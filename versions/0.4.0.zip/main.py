import numpy as np
import tkinter as tk
from PIL import Image, ImageDraw, ImageTk
from updater import Updater


class Main:
    def __init__(self):
        Updater()
    def create_image(self, width, height, color):
        return Image.new("RGBA", (width, height), color)

    def draw_circle(self, image, x, y, radius, color):
        draw = ImageDraw.Draw(image)
        draw.ellipse(
            (x - radius, y - radius, x + radius, y + radius),
            fill=color,
        )
        return image

    def vignette(self, image, intensity):
        pixels = np.array(image.convert("RGB"), dtype=np.float32)
        height, width = pixels.shape[:2]

        y, x = np.ogrid[:height, :width]
        center_x = (width - 1) / 2
        center_y = (height - 1) / 2

        distance = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
        max_distance = max(np.hypot(center_x, center_y), 1)

        mask = np.clip(1 - distance / max_distance * intensity, 0, 1)
        pixels *= mask[..., np.newaxis]

        return Image.fromarray(np.clip(pixels, 0, 255).astype(np.uint8))

    def hue_noise(self, image, intensity):
        intensity = int(intensity)
        if intensity < 0:
            raise ValueError("intensity muss mindestens 0 sein.")

        hsv = image.convert("HSV")
        pixels = np.array(hsv, dtype=np.uint8)
        rng = np.random.default_rng()

        noise = rng.integers(
            -intensity,
            intensity + 1,
            size=pixels.shape[:2],
        )

        pixels[..., 0] = (
            (pixels[..., 0].astype(np.int64) + noise) % 256
        ).astype(np.uint8)

        return Image.frombytes("HSV", hsv.size, pixels.tobytes()).convert("RGB")

    def display_image(self, image):
        root = tk.Tk()
        root.title("Mein Bild")
        root.geometry("800x800")
        root.minsize(200, 200)

        label = tk.Label(root, borderwidth=0, highlightthickness=0)
        label.pack(fill=tk.BOTH, expand=True)

        original = image.copy()

        def resize_image(event):
            if event.width < 1 or event.height < 1:
                return

            resized = original.resize(
                (event.width, event.height),
                Image.Resampling.NEAREST,
            )
            photo = ImageTk.PhotoImage(resized, master=root)
            label.configure(image=photo)
            label.image = photo

        label.bind("<Configure>", resize_image)
        root.mainloop()

    def gradient_top_buttom(self, image, top_color, bottom_color):
        base = image.convert("RGBA")
        width, height = base.size

        # RGB: 0–255, Alpha: 0.0–1.0
        top = np.array(top_color, dtype=np.float32)
        bottom = np.array(bottom_color, dtype=np.float32)
        top[3] *= 255
        bottom[3] *= 255

        ratio = np.linspace(0, 1, height)[:, None, None]
        rows = top[None, None, :] * (1 - ratio) + bottom[None, None, :] * ratio

        pixels = np.broadcast_to(rows, (height, width, 4))
        gradient = Image.fromarray(
            np.clip(pixels, 0, 255).astype(np.uint8)
        )

        return Image.alpha_composite(base, gradient)

    def draw_stars(self, image, num_stars, color):
        base = image.convert("RGBA")
        width, height = base.size

        pixels = np.array(base, dtype=np.uint8)
        rng = np.random.default_rng()

        for _ in range(num_stars):
            x = rng.integers(0, width)
            y = rng.integers(0, height)
            pixels[y, x, :4] = color

        return Image.fromarray(pixels)

    def perlin_noise(self, image, scale=10, intensity=0.5):
        base = image.convert("RGBA")
        width, height = base.size

        pixels = np.array(base, dtype=np.uint8)
        rng = np.random.default_rng()

        noise = rng.random((height, width)) * 255 * intensity
        for y in range(height):
            for x in range(width):
                pixels[y, x, :3] = np.clip(pixels[y, x, :3].astype(np.float32) + noise[y, x], 0, 255)

        return Image.fromarray(pixels)


if __name__ == "__main__":
    app = Main()

    img = app.create_image(200, 200, (200, 200, 255, 255))
    img = app.draw_circle(img, 100, 100, 50, (255, 255, 0, 255))
    img = app.hue_noise(img, 5)
    img = app.gradient_top_buttom(img, (0, 0, 100, 0.5), (162, 47, 0, .8))
    img = app.perlin_noise(img, scale=1, intensity=0.2)
    img = app.vignette(img, 0.5)
    img = app.draw_stars(img, 50, (255, 255, 255, 255))

    app.display_image(img)