"""GitHub updates for the source-based application. Updater() checks on startup."""

import os
import queue
import re
import shutil
import sys
import tempfile
import threading
import tkinter as tk
import zipfile
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk
from urllib.parse import quote

import requests
import yaml

WORKSPACE = Path(__file__).resolve().parent
DOWNLOAD_BASE_URL = "https://raw.githubusercontent.com/XenonMax123/Updater/main"
VERSION_FILE = "version.yaml"
ENTRY_POINT = "main.py"
BACKUP_FOLDER = ".update-backups"
# Keep this updater until releases provide a compatible updater migration.
EXCLUDED_NAMES = {"updater.py", "__pycache__", BACKUP_FOLDER, ".git"}


def parse_version(document: str) -> str:
    """Read the numeric release format used by this application (e.g. 0.3.0)."""
    data = yaml.safe_load(document)
    if not isinstance(data, dict):
        raise ValueError("Die Versionsdatei muss ein YAML-Mapping enthalten.")
    version = str(data.get("version", ""))
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        raise ValueError(f"Ungueltige Versionsnummer: {version!r}")
    return version

def version_key(version: str) -> tuple[int, ...]:
    return tuple(int(part) for part in version.split("."))

class UpdateDialog:
    """Own all Tk widgets; the worker communicates only through a queue."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.results = queue.Queue()
        self.succeeded = False

    def confirm(self, version: str) -> bool:
        return messagebox.askyesno(
            "Update verfuegbar", f"Version {version} herunterladen und installieren?",
            parent=self.root,
        )

    def run(self, install, version: str) -> bool:
        self.root.title("Update installieren")
        self.root.geometry("450x130")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        ttk.Label(self.root, text="Update wird heruntergeladen und installiert ...").pack(pady=20)
        self.progress = ttk.Progressbar(self.root, mode="indeterminate")
        self.progress.pack(fill="x", padx=20)
        self.progress.start(15)
        self.root.deiconify()
        threading.Thread(target=self._install, args=(install, version), daemon=True).start()
        self.root.after(100, self._poll)
        self.root.mainloop()
        return self.succeeded

    def _install(self, install, version: str) -> None:
        try:
            install(version)
        except Exception as error:
            self.results.put(error)
        else:
            self.results.put(None)

    def _poll(self) -> None:
        try:
            error = self.results.get_nowait()
        except queue.Empty:
            self.root.after(100, self._poll)
            return
        self.progress.stop()
        self.root.withdraw()
        self.succeeded = error is None
        if error is not None:
            messagebox.showerror("Update fehlgeschlagen", str(error), parent=self.root)
        self.root.quit()

class Updater:
    def __init__(self, workspace: Path = WORKSPACE, *, auto_run: bool = True):
        self.workspace = Path(workspace).resolve()
        if auto_run:
            self.run()

    def run(self) -> None:
        """Check, ask, install, then restart. Declining continues the application."""
        try:
            current = self.read_version(self.workspace / VERSION_FILE)
            newest = self.fetch_latest_version()
        except (OSError, requests.RequestException, yaml.YAMLError, ValueError) as error:
            print(f"Update-Pruefung fehlgeschlagen: {error}")
            return
        print(f"Installiert: {current}; GitHub: {newest}")
        if version_key(newest) <= version_key(current):
            return
        if self.prompt_and_install(newest):
            self.restart()

    @staticmethod
    def read_version(path: Path) -> str:
        return parse_version(path.read_text(encoding="utf-8-sig"))

    def fetch_latest_version(self) -> str:
        url = f"{DOWNLOAD_BASE_URL}/release_info.yaml"
        with requests.get(url, timeout=10, headers={"Cache-Control": "no-cache"}) as response:
            response.raise_for_status()
            if "text/html" in response.headers.get("Content-Type", "").lower():
                raise ValueError("GitHub liefert HTML statt YAML. Raw-Download-Adresse pruefen.")
            return parse_version(response.text)

    def prompt_and_install(self, version: str) -> bool:
        root = tk.Tk()
        root.withdraw()
        try:
            dialog = UpdateDialog(root)
            return dialog.confirm(version) and dialog.run(self.install_release, version)
        finally:
            root.destroy()

    def install_release(self, version: str) -> None:
        with tempfile.TemporaryDirectory(prefix="myprogram-update-") as folder:
            stage = Path(folder)
            archive = stage / "release.zip"
            extracted = stage / "files"
            self.download_release(version, archive)
            self.extract_release(archive, extracted)
            self.validate_release(extracted, version)
            self.replace_files(extracted)
        print(f"Version {version} erfolgreich installiert.")

    @staticmethod
    def download_release(version: str, destination: Path) -> None:
        url = f"{DOWNLOAD_BASE_URL}/versions/{quote(version, safe='')}.zip"
        with requests.get(url, stream=True, timeout=(10, 60)) as response:
            response.raise_for_status()
            with destination.open("wb") as target:
                for chunk in response.iter_content(64 * 1024):
                    target.write(chunk)

    @staticmethod
    def extract_release(archive: Path, destination: Path) -> None:
        destination.mkdir()
        with zipfile.ZipFile(archive) as release:
            for entry in release.infolist():
                target = (destination / entry.filename).resolve()
                if not target.is_relative_to(destination.resolve()):
                    raise ValueError("Ungueltiger Pfad im Update-Archiv.")
            release.extractall(destination)

    def validate_release(self, folder: Path, version: str) -> None:
        if not (folder / ENTRY_POINT).is_file():
            raise ValueError(f"{ENTRY_POINT} fehlt im Update-Archiv.")
        if self.read_version(folder / VERSION_FILE) != version:
            raise ValueError("Die Version im Archiv stimmt nicht mit release_info.yaml ueberein.")

    @staticmethod
    def release_files(folder: Path) -> list[Path]:
        files = [path.relative_to(folder) for path in folder.rglob("*")
                 if path.is_file() and not EXCLUDED_NAMES.intersection(path.relative_to(folder).parts)]
        # Mark the installation complete only after all program files are written.
        return sorted(files, key=lambda path: (path == Path(VERSION_FILE), str(path)))

    def replace_files(self, folder: Path) -> None:
        backup = self.workspace / BACKUP_FOLDER / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        files = self.release_files(folder)
        self.backup_files(files, backup)
        changed = []
        try:
            for relative in files:
                target = self.workspace / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                changed.append(relative)
                shutil.copy2(folder / relative, target)
        except Exception:
            self.restore_files(changed, backup)
            raise
        print(f"Sicherung: {backup}")

    def backup_files(self, files: list[Path], backup: Path) -> None:
        backup.mkdir(parents=True)
        for relative in files:
            source = self.workspace / relative
            if source.exists():
                saved = backup / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, saved)

    def restore_files(self, files: list[Path], backup: Path) -> None:
        for relative in reversed(files):
            target = self.workspace / relative
            saved = backup / relative
            if saved.exists():
                shutil.copy2(saved, target)
            else:
                target.unlink(missing_ok=True)

    def restart(self) -> None:
        os.execv(sys.executable, [sys.executable, str(self.workspace / ENTRY_POINT), *sys.argv[1:]])

if __name__ == "__main__":
    Updater()
